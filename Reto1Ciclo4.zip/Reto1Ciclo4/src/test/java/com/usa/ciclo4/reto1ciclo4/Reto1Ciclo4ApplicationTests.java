package com.usa.ciclo4.reto1ciclo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto1Ciclo4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
